﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Runtime;

namespace ConsoleApplication
{
    public class ClassSSIS
    {
        public void runPack(string b)
        {
            String PackAge = @"C:\Users\No Name\Desktop\Luat\yc2\Integration Services Project\Integration Services Project\Package.dtsx";
            Package ssisPackage;
            Application app;
            DTSExecResult result;
            Variables vars;

            app = new Application();
            ssisPackage = app.LoadPackage(PackAge, null);

            vars = ssisPackage.Variables;
            vars["source"].Value = b;

            result = ssisPackage.Execute();
            if (result == DTSExecResult.Success)
                Console.WriteLine("add thanh cong.");
            else if (result == DTSExecResult.Failure)
                Console.WriteLine("add that bai!");
        }
    }
}
