﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Can thay doi duong dan den file ssis package!!");
            Console.WriteLine("Nhap duong dan toi file input: ");
            string b;
            b = Console.ReadLine();
            ClassSSIS a = new ClassSSIS();
            a.runPack(b);
        }
    }
}
